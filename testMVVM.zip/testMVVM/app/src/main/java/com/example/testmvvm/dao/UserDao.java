package com.example.testmvvm.dao;

import androidx.room.Dao;
import androidx.room.*;

import com.example.testmvvm.model.User;

@Dao
public interface UserDao {
    @Insert
    void insert(User user);

    @Insert
    void insertAll(User... users);
}
